# WooCommerce khipu

## Instalación

1. Descomprime el plugin a la carpeta `/wp-content/plugins/`
2. Activa el plugin en el menú 'Plugins' en Wordpress
3. Configura el nuevo medio de pago en  WooCommerce -> Settings -> Payment Gateways
