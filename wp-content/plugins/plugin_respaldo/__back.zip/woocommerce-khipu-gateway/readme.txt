=== WooCommerce khipu ===
Contributors: khipu
Donate link: 
Tags: payment gateway, khipu, woocommerce, chile
Requires at least: 3.3
Tested up to: 4.1
Stable tag: 2.7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Permite el uso de khipu en WooCommerce, khipu es un medio de pago que permite pagar usando Cuentas Bancarias, tarjetas de crédito, débito y prepago.

== Description ==

Permite el uso de khipu en WooCommerce, khipu es un medio de pago que permite pagar usando Cuentas Bancarias, tarjetas de crédito, débito y prepago.

== Installation ==

1. Descomprime el plugin a la carpeta `/wp-content/plugins/`
2. Activa el plugin en el menú 'Plugins' en Wordpress
3. Configura el nuevo medio de pago en  WooCommerce -> Settings -> Payment Gateways

== Frequently asked questions ==

No hay preguntas aún.

== Screenshots ==

1. https://s3.amazonaws.com/static.khipu.com/woocommerce/activate-plugin.png
2. https://s3.amazonaws.com/static.khipu.com/woocommerce/khipu-settings.png
3. https://s3.amazonaws.com/static.khipu.com/id-cobrador.png

== Changelog ==
2.7 Mejoras de UX
2.6 Se agrega soporte para Webpay
2.5 Se agrega soporte para PayMe
1.6 Mejoras para compatibilidad con php 5.2
1.5 Uso de API de notificación 1.3
1.4 Chequeo de existencia del plugin WooCommerce
1.3 Uso de API khipu 1.3
1.0 Versión inicial


== Upgrade notice ==

Versión inicial
