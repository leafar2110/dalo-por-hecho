<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Mar de Rosas
 */

get_header();
   global $wpdb;  

get_footer();
