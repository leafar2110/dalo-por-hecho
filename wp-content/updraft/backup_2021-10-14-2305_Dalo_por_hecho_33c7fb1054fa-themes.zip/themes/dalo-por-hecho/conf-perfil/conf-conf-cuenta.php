<?php global $current_user, $wp_roles; ?>
                            <!-- tab conf -->
                            <div class="tab-pane fade" id="v-pills-conf" role="tabpanel" aria-labelledby="v-pills-conf-tab">
                              <div id="post-<?php the_ID(); ?>">
                                <div class="entry-content entry">
                                  <?php the_content(); ?>
                                  <?php if ( !is_user_logged_in() ) : ?>
                                    <p class="warning">
                                      <?php _e('You must be logged in to edit your profile.', 'profile'); ?>
                                    </p><!-- .warning -->
                                  <?php else : ?>
                                  <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>                                
                                    <div class="card">
                                      <div class="card-header top-headline" role="tab" id="headingOne">
                                        <h5>
                                          <div class="cont-img-conf-cuenta_a">
                                            <a class="ver-perfil-publico" href="perfil">Ver tu perfil publico</a>
                                          </div>
                                          <a data-toggle="collapse"  aria-expanded="true" aria-controls="collapseOne">
                                            <div class="cont-top-conf-cuenta">
                                              <div class="cont-top-conf-cuenta_h4">
                                                Cuenta 
                                                <?php $urlsinparametros= explode('=', $_SERVER['REQUEST_URI'], 2);
                                                $urlsin = $urlsinparametros[1]; ?>
                                              </div>
                                              <div class="barra-progreso">
                                                <h6>Completa tu perfil para mejorar tus oportunidades de trabajo </h6><br>
                                                <div class="cont-barra-progreso">
                                                  <div class="progress">
                                                    <div class="progress-bar" style="width:<?php echo $porcent; ?>%">  </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </a>
                                        </h5>
                                      </div>
                                      <div id="collapseOne" class="collapse show mb-5" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion">
                                        <?php if ( $_GET['mconf'] == 'save' ) {  ?>         
                                          <div class="woocommerce-notices-wrapper">
                                            <div class="woocommerce-message" role="alert">
                                              “Sus datos han sido guardados correctamente.
                                            </div> 
                                          </div>
                                        <?php } ?> 
                                        <ul class="nav nav-tabs h-p-nav-tab">
                                          <li class="nav-item">
                                            <a class="nav-link rol_user-tab active" id="item-perfil" data-toggle="tab" href="#rol_user">
                                              Cambiar Rol 
                                            </a>                                                      
                                          </li>   
                                          <li class="nav-item">
                                            <a class="nav-link imagen-perfil-tab" id="item-perfil" data-toggle="tab" href="#imagen-perfil">   
                                              Imagen Perfil 
                                            </a>
                                          </li>
                                          <li class="nav-item">
                                            <a class="nav-link imagen-perfil-tab" id="item-perfil" data-toggle="tab" href="#foto-portada">   
                                              Foto Portada
                                            </a>
                                          </li> 
                                          <li class="nav-item">
                                            <a class="nav-link imagen-perfil-tab" id="item-perfil" data-toggle="tab" href="#datos-personales">   
                                              Datos Personales
                                            </a>
                                          </li>                                                       
                                        </ul> 

                                        <div class="tab-content">

                                          <!-- Imagen Perfil -->   
                                          <div id="rol_user" class="container tab-pane active"><br>
                                            <div class="cont-pago-estado">
                                              <div class="cont-pago-estado-tab">
                                                <p>Cambiar Rol de Usuario</p>
                                                <h6>Que deseas en DALO POR HECHO </h6>
                                                <div class="opc-conf-cuenta">
                                                  <form method="post" id="adduser" action="<?php echo get_home_url(); ?>/save">  
                                                    <input type="hidden" name="name_form" value="rol" />
                                                    <label class="radio-inline">
                                                      <input type="radio" name="user_registration_radio_1600171615" id="user_registration_radio_1600171615" value="Publicar Tareas"  <?php if( meta_user_value( 'user_registration_radio_1600171615', $current_user->ID ) == "Publicar Tareas" ){ echo 'checked="checked"';} ?>>Publicar Tareas
                                                    </label>
                                                    <label class="radio-inline">
                                                      <input type="radio" name="user_registration_radio_1600171615" id="user_registration_radio_1600171615" value="Hacer tareas" <?php if( meta_user_value( 'user_registration_radio_1600171615', $current_user->ID ) == "Hacer tareas" ){ echo 'checked="checked"';} ?>>Hacer tareas
                                                    </label>
                                                    <div class="cont-boton-cambios">
                                                      <input name="updateuser" type="submit" id="updateuser" class="guardar-cambios" value="Guardar cambios" />
                                                                <?php wp_nonce_field( 'update-user' ) ?>
                                                      <input name="action" type="hidden" id="action" value="update-user" />
                                                    </div>
                                                  </form>                                                         
                                                </div>                                               
                                              </div>
                                            </div>
                                          </div> 
 
                                          <!-- Imagen Perfil -->                                    
                                          <div id="imagen-perfil" class="container tab-pane  fade"><br>
                                             <div class="cont-pago-estado">
                                                 <div class="cont-pago-estado-tab">
                                                    <p>Imagen Perfil</p>
                                                    <div class="cont-img-conf-cuenta"> 
                                                       <?php echo do_shortcode('[user_profile_avatar_upload]');?>
                                                     </div>                                     
                                                 </div>
                                             </div>
                                         </div>  

                                        <!-- Imagen Perfil -->                                    
                                        <div id="foto-portada" class="container tab-pane  fade"><br>
                                          <div class="cont-pago-estado">
                                            <div class="cont-pago-estado-tab">
                                              <p>Foto Portada</p>
                                              <div class="cont-inf-conf-cuenta">
                                                <h6>Mejora tu perfil y has mas atractivo tu feed<?php echo $user_actual ?></h6>
                                                <div class="row cont-row-form">
                                                  <div class="subir-foto col-md-6">
                                                    <?php if(meta_value_img_frm($current_user->ID,7) == NULL){ ?>
                                                      <h6>Subir foto de portada<?php echo meta_value_img_frm($current_user->ID,7); ?></h6>
                                                    <?php }else{ ?>   
                                                      <img src="<?php echo meta_value_img_frm($current_user->ID,7); ?>"> 
                                                    <?php } ?>                                                   
                                                  </div>
                                                  <div class="col-md-6">
                                                    <h6>Subir foto de portada</h6>
                                                    <?php echo do_shortcode('[frm-set-get id_user='.$current_user->ID.'][formidable id=7]');  ?>
                                                  </div>  
                                                 </div>                                          
                                              </div>
                                            </div>  
                                          </div>
                                        </div>                                                                      

                                          <!-- Datos Personales -->                                    
                                          <div id="datos-personales" class="container tab-pane  fade"><br>
                                            <div class="cont-pago-estado">
                                              <div class="cont-pago-estado-tab">
                                                <p>Datos Personales</p>
                                                <div class="form-conf-cuenta">
                                                  <form method="post" id="adduser" action="<?php echo get_home_url(); ?>/save">                        
                                                    <div class="row cont-row-form">
                                                      <div class="col-md-6">
                                                        <input class="form-control" placeholder="Nombre y Apellido" name="first-name" type="text" id="first-name" value="<?php the_author_meta( 'first_name', $current_user->ID ); ?>" />
                                                        <input type="hidden" name="name_form" value="conf" />
                                                      </div>
                                                      <div class="col-md-6">
                                                        <input class="form-control" placeholder="Dirección" name="direccion_user" type="text" id="direccion_user" value="<?php the_author_meta( 'direccion_user', $current_user->ID ); ?>" />
                                                      </div>
                                                    </div>
                                                    <div class="row cont-row-form">
                                                      <div class="col-md-6">
                                                        <input class="form-control" placeholder="Escribe tu frase" name="frase_user" type="text" id="frase_user" value="<?php the_author_meta( 'frase_user', $current_user->ID ); ?>" />
                                                      </div>
                                                      <div class="col-md-6">
                                                        <input type="email" class="form-control" id="email"  placeholder="Enter email" name="email" value="<?php the_author_meta( 'user_email', $current_user->ID ); ?>" />
                                                      </div>
                                                    </div>                                           
                                                    <h6>Fecha de cumpleaños </h6>
                                                    <div class="form-inline cumple">
                                                      <input type="text" class="form-control" placeholder="DD" name="dia" id="dia" maxlength="2" value="<?php if (meta_user_value( 'fecha_nac_user', $current_user->ID )!=NULL) {echo date('d', strtotime(meta_user_value( 'fecha_nac_user', $current_user->ID ))); }?>">
                                                      <input type="text" class="form-control" placeholder="MM" name="mes" id="mes" min="1" max="12" maxlength="2" value="<?php if (meta_user_value( 'fecha_nac_user', $current_user->ID )!=NULL) {echo date('m', strtotime(meta_user_value( 'fecha_nac_user', $current_user->ID ))); }?>">
                                                      <input type="text" class="form-control" placeholder="AA" name="ano" id="ano" min="1900" maxlength="4" value="<?php if (meta_user_value( 'fecha_nac_user', $current_user->ID )!=NULL) {echo date('Y', strtotime(meta_user_value( 'fecha_nac_user', $current_user->ID ))); }?>">
                                                      <input type="hidden" class="form-control" id="fecha_nac_user" placeholder="Enter email" name="fecha_nac_user" value="<?php echo meta_user_value( 'fecha_nac_user', $current_user->ID ) ?>" />
                                                    </div>
                                                    <h6>Agrega tu descripción</h6>
                                                    <textarea name="description" id="description" rows="10" cols="30" class="textarea-conf"><?php the_author_meta( 'description', $current_user->ID ); ?></textarea>
                                                    
                                                    <div class="cont-boton-cambios">
                                                      <input name="updateuser" type="submit" id="updateuser" class="guardar-cambios" value="Guardar cambios" />
                                                          <?php wp_nonce_field( 'update-user' ) ?>
                                                      <input name="action" type="hidden" id="action" value="update-user" />
                                                      <a class="desactivar-cuenta" href="#">Desactivar cuenta</a>               
                                                    </div>
                                                  </form>
                                                </div>    
                                              </div>
                                            </div>
                                          </div>                                                   

                                        </div>
                                      </div>
                                    </div>                                                   
                                  <?php endif; ?>
                                </div>
                              </div>
                            </div>

                          
                        