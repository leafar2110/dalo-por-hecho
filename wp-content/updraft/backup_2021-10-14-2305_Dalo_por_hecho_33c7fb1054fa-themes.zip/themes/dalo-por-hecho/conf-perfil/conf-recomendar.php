<?php global $current_user, $wp_roles; ?>
                            <!--tab recomendar -->                            
                            <div class="tab-pane fade" id="v-pills-recomendar" role="tabpanel"
                                aria-labelledby="v-pills-three-tab">
                                <div class="content-recomendar-amigo">
                                    <h5>Recomendar a un amigo</h5>
                                    <div class="content-recomendar-amigo-creditos">
                                        <div class="content-recomendar-amigo-creditos-inf">
                                            <h4>Obtenga créditos invitando amigos</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.Lorem ipsum dolor
                                                sit amet consectetur adipisicing elit.</p>
                                            <div class="recomendar-link">
                                                <div class="recomendar-link-copiar">
                                                    <input type="text" placeholder="http://www.daloporhecho.com/nombreuser-2020">
                                                </div>
                                                <div class="recomendar-link_a">
                                                    <a class="btn-a-dl" href="#">Copiar link</a>
                                                </div>
                                            </div>
                                            <div class="compartir-en-rs">
                                                <p>Compartir en redes sociales</p>
                                                <div class="redes-sociales-crs">
                                                    <div class="div-rs"></div>
                                                    <div class="div-rs"></div>
                                                    <div class="div-rs"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="recomendar-funcionamiento">
                                        <h4>Como funcionan las referencias</h4>
                                        <div class="container">
                                            <div class="row recomendar-funcionamiento_row">
                                                <div class="col-md-4 col-sm-6 recomendar-funcionamiento-col">
                                                    <div class="recomendar-funcionamiento-num">1</div>
                                                    <h6>Invita a tus amigos</h6>
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus
                                                        fuga magni</p>
                                                </div>
                                                <div class="col-md-4 col-sm-6 recomendar-funcionamiento-col">
                                                    <div class="recomendar-funcionamiento-num">2</div>
                                                    <h6>Debe realizar su primera tarea</h6>
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus
                                                        fuga magni</p>
                                                </div>
                                                <div class="col-md-4 col-sm-6 recomendar-funcionamiento-col">
                                                    <div class="recomendar-funcionamiento-num">3</div>
                                                    <h6>Obten $ 10 de credito</h6>
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus
                                                        fuga magni</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>  