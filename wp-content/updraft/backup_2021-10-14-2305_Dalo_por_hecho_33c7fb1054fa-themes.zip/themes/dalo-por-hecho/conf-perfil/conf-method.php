<?php global $current_user, $wp_roles; ?>
                            <!-- tab method -->
                            <div class="tab-pane fade" id="v-pills-method" role="tabpanel"
                                aria-labelledby="v-pills-method-tab">
                                <p>Eu dolore ea ullamco dolore Lorem id cupidatat excepteur reprehenderit consectetur
                                    elit id
                                    dolor proident in cupidatat officia. Voluptate excepteur commodo labore nisi cillum
                                    duis
                                    aliqua do. Aliqua amet qui mollit consectetur nulla mollit velit aliqua veniam nisi
                                    id do
                                    Lorem deserunt amet. Culpa ullamco sit adipisicing labore officia magna elit nisi in
                                    aute
                                    tempor commodo eiusmod.
                                </p>
                            </div> 