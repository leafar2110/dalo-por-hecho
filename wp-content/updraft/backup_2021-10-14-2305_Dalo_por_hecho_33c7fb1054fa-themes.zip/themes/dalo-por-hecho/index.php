<?php get_header(); ?>

<?php get_template_part('sections/home/main-banner'); ?>
<?php get_template_part('sections/home/main-tareas'); ?>
<?php get_template_part('sections/home/main-cta'); ?>
<?php get_template_part('sections/home/main-tareas-2'); ?>

<?php get_template_part('sections/home/main-testimonios'); ?>
<?php get_template_part('sections/home/main-funciona'); ?>
<?php get_template_part('sections/home/main-testimonios-2'); ?>
<?php get_template_part('sections/home/main-container'); ?>
<?php get_template_part('sections/home/main-modal-step'); ?>

<?php get_footer(); ?>